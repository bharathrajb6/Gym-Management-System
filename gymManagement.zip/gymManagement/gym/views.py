import datetime
import random
from django.shortcuts import render, redirect
from gym.models import Customer, Trainer, Attendance_Customer, Attendance_Trainer, Booking, Service, Payment, Package, \
    notifications, feedback
from django.contrib.auth.models import auth, User
from django.contrib.auth.decorators import login_required
from django.contrib import messages
import smtplib
from .forms import PackageForm, ServiceForm,UpdateInformation


def index(request):
    return render(request, 'index.html')


def aboutUs(request):
    return render(request, 'aboutUs.html')


def packageList(request):
    obj = Package.objects.all()
    return render(request, 'packageList.html', {'packageList': obj})


def contactUs(request):
    if request.method == 'POST':
        name = request.POST['name']
        email = request.POST['email']
        msg = request.POST['msg']
        try:
            s = smtplib.SMTP('smtp.gmail.com', 587)
            s.starttls()
            s.login("bharathsr2001@gmail.com", "Bharath@B26")
            message = "Contact \n\nName : {}\nEmail : {}\n\n{}".format(name, email, msg)
            s.sendmail(email, "bharathsr2001@gmail.com", message)
            s.quit()
            messages.success(request, 'Successfully Sent')

        except:
            messages.error(request, 'Unable to sent ..')
        return redirect('contactUs')
    else:
        return render(request, 'contactUs.html')


@login_required(login_url='/admin/login')
def trainerManage(request):
    if request.user.is_superuser:
        obj = Trainer.objects.all().order_by('id')
        return render(request, 'admin/trainerManage.html', {'trainersList': obj})


@login_required(login_url='/admin/login')
def customerManage(request):
    if request.user.is_superuser:
        obj = Customer.objects.all()
        return render(request, 'admin/customerManage.html', {'customersList': obj})


def adminLogin(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        passwd = request.POST.get('password')
        admin = auth.authenticate(username=username, password=passwd, is_superuser=True)
        if admin is not None:
            auth.login(request, admin)
            return redirect('adminMenu')
        else:
            messages.error(request, 'Not Found')
            return redirect('adminLogin')
    else:
        return render(request, 'admin/login.html')


def adminLogout(request):
    if request.user.is_superuser:
        auth.logout(request)
        return redirect('adminLogin')


@login_required(login_url='admin/login')
def adminMenu(request):
    if request.user.is_superuser:
        obj = Customer.objects.all()
        totalCustomers = len(list(obj))
        obj1 = Trainer.objects.all()
        totalTrainers = len(list(obj1))
        obj2 = Package.objects.all()
        totalPackages = len(list(obj2))
        obj3 = Booking.objects.all()
        totalBookings = len(list(obj3))

        return render(request, 'admin/adminMenu.html',
                      {'totalCustomers': totalCustomers, 'totalTrainers': totalTrainers,
                       'totalPackages': totalPackages,'totalBookings':totalBookings})
    else:
        return redirect('index')


@login_required(login_url='admin/login')
def customerAttendance(request):
    if request.user.is_superuser:
        todayDate = datetime.date.today()
        print(todayDate)
        obj = Attendance_Customer.objects.filter(date=todayDate)
        return render(request, 'admin/customerAttendance.html', {'list': obj})


@login_required(login_url='/admin/login')
def trainerAttendance(request):
    if request.user.is_superuser:
        todayDate = datetime.date.today()
        print(todayDate)
        obj = Attendance_Trainer.objects.filter(date=todayDate)
        return render(request, 'admin/trainerAttendance.html', {'list': obj})


@login_required(login_url='/admin/login')
def addCustomerAttendance(request):
    if request.user.is_superuser:
        if request.method == 'POST':
            cID = request.POST['customerID']
            date = request.POST['date']
            print(date)
            isPresent = request.POST['isPresent']
            id = random.randint(100, 1000000)
            try:
                customerID = Customer.objects.get(id=cID)
            except:
                customerID = None
            if customerID is not None:
                if Attendance_Customer.objects.filter(customerID=customerID, date=date).exists():
                    messages.error(request, 'Already taken.')
                    return redirect('addCustomerAttendance')
                else:
                    datee = datetime.datetime.strptime(date, "%Y-%m-%d")
                    month = datee.month
                    year = datee.year
                    print(month)
                    print(year)
                    monthValue = "{0}-0{1}".format(year, month)
                    print(monthValue)
                    obj = Attendance_Customer(id=id, customerID=customerID, date=date, monthValue=monthValue,
                                              isPresent=isPresent)
                    obj.save()
                    messages.success(request, 'Taken Successfully.')
                    return redirect('customerAttendance')
            else:
                messages.error(request, 'Customer ID is not found.')
                return redirect('addCustomerAttendance')
        else:
            return render(request, 'admin/addCustomerAttendance.html')
    else:
        return render(request, 'admin/adminLogin.html')



@login_required(login_url='/admin/login')
def addTrainerAttendance(request):
    if request.user.is_superuser:
        if request.method == 'POST':
            tID = request.POST['trainerID']
            date = request.POST['date']
            isPresent = request.POST['isPresent']
            try:
                trainerID = Trainer.objects.get(id=tID)
            except:
                trainerID = None
            if trainerID is not None:
                if Attendance_Trainer.objects.filter(trainer_ID=trainerID, date=date).exists():
                    messages.error(request, 'Already taken')
                    return redirect('addTrainerAttendance')
                else:
                    id = random.randint(100, 10000000)
                    datee = datetime.datetime.strptime(date, "%Y-%m-%d")
                    month = datee.month
                    year = datee.year
                    print(month)
                    print(year)
                    monthValue = "{0}-0{1}".format(year, month)
                    print(monthValue)
                    obj = Attendance_Trainer(id=id, trainer_ID=trainerID, date=date, monthValue=monthValue,
                                             IsPresent=isPresent)
                    obj.save()
                    messages.success(request, 'Taken Successfully')
                    return redirect('trainerAttendance')
            else:
                messages.error(request, 'Trainer ID is not found.Please Check it.')
                return redirect('addTrainerAttendance')
        else:
            return render(request, 'admin/addTrainerAttendance.html')
    else:
        return render(request, 'admin/adminLogin.html')


@login_required(login_url='/admin/login')
def adminPackageList(request):
    if request.user.is_superuser:
        obj = Package.objects.all()
        return render(request, 'admin/packageList.html', {'packageList': obj})


@login_required(login_url='/admin/login')
def addPackage(request):
    if request.user.is_superuser and request.method == 'POST':
        form = PackageForm(request.POST, request.FILES)
        if form.is_valid():
            form.save()
        return redirect('adminPackageList')
    elif request.user.is_superuser:
        form1 = PackageForm()
        return render(request, 'admin/addPackage.html', {'form': form1})
    else:
        pass


@login_required(login_url='/admin/login')
def editPackage(request):
    if request.user.is_superuser and request.method == 'POST':
        id1 = request.POST['id']
        obj = Package.objects.get(id=id1)
        return render(request, 'admin/editPackage.html', {'data': obj})


@login_required(login_url='/admin/login')
def editPackageDetails(request):
    if request.user.is_superuser and request.method == 'POST':
        id = request.POST['id']
        desc = request.POST['desc']
        price = request.POST['price']
        img = request.POST['img']
        obj = Package.objects.get(id=id)
        obj.package_Desc = desc
        obj.package_Price = price
        obj.package_Image = img
        obj.save()
        return redirect('adminPackageList')


@login_required(login_url='/admin/login')
def deletePackage(request):
    if request.user.is_superuser and request.method == 'POST':
        id = request.POST['id']
        obj = Package.objects.get(id=id)
        obj.delete()
        return redirect('adminPackageList')


@login_required(login_url='/admin/login')
def bookingsList(request):
    if request.user.is_superuser:
        obj = Booking.objects.all()
        return render(request, 'admin/bookingsList.html', {'bookingList': obj})


@login_required(login_url='/admin/login')
def deleteBooking(request):
    if request.user.is_superuser:
        id = request.POST['id']
        obj = Booking.objects.get(bookingID=id)
        obj.delete()
        return redirect('bookingsList')


@login_required(login_url='/admin/login')
def addBooking(request):
    if request.user.is_superuser and request.method == 'POST':
        customerID = request.POST['customerID']
        packageID = request.POST['packageID']
        date = request.POST['date']
        isAccepted = request.POST['isAccepted']
        try:
            customerID = Customer.objects.get(id=customerID)
        except:
            customerID = None
        try:
            pid = Package.objects.get(id=packageID)
        except:
            pid = None
        if customerID is not None:
            if pid is not None:
                obj = Booking(customerID=customerID, packageID=pid, date=date, IsAccepted=isAccepted)
                obj.save()
                return redirect('bookingsList')
            else:
                messages.error(request, 'Package ID is not found.')
        else:
            messages.error(request, 'Customer ID is not found.')
        return redirect('bookingsList')


@login_required(login_url='/admin/login')
def paymentsList(request):
    if request.user.is_superuser:
        obj = Payment.objects.all()
        return render(request, 'admin/paymentsList.html', {'paymentList': obj})


@login_required(login_url='/admin/login')
def servicesList(request):
    if request.user.is_superuser:
        obj = Service.objects.all()
        return render(request, 'admin/servicesList.html', {'serviceList': obj})


@login_required(login_url='/admin/login')
def addService(request):
    if request.user.is_superuser and request.method == 'POST':
        form = ServiceForm(request.POST, request.FILES)
        if form.is_valid():
            form.save()
        return redirect('servicesList')
    elif request.user.is_superuser:
        form1 = ServiceForm()
        return render(request, 'admin/addService.html', {'form': form1})
    else:
        pass


@login_required(login_url='/admin/login')
def editService(request):
    if request.user.is_superuser and request.method == 'POST':
        id1 = request.POST['id']
        obj = Service.objects.get(id=id1)
        return render(request, 'admin/editService.html', {'data': obj})


@login_required(login_url='/admin/login')
def editServiceDetails(request):
    if request.user.is_superuser and request.method == 'POST':
        id = request.POST['id']
        obj = Service.objects.get(id=id)
        obj.servicePrice = request.POST['price']
        obj.serviceImage = request.POST['img']
        obj.serviceDesc = request.POST['desc']
        obj.save()
        return redirect('servicesList')


@login_required(login_url='/admin/login')
def deleteService(request):
    if request.user.is_superuser and request.method == 'POST':
        id = request.POST['id']
        obj = Service.objects.get(id=id)
        obj.delete()
        return redirect('servicesList')


@login_required(login_url='/admin/login')
def addTrainer(request):
    if request.user.is_superuser and request.method == 'POST':
        name = request.POST['name']
        email = request.POST['email']
        mbl = request.POST['mbl']
        address = request.POST['address']
        passwd = request.POST['password']
        active = request.POST['isActive']
        if Trainer.objects.filter(mbl=mbl).exists():
            messages.error(request, 'Phone Number is already exists.')
            return redirect('trainerManage')
        else:
            id = random.randint(100, 1000)
            obj = Trainer(id=id, name=name, isActive=active, email=email, mbl=mbl, password=passwd, address=address)
            obj.save()
            messages.success(request, 'Added Successfully !!')
            return redirect('trainerManage')


@login_required(login_url='/admin/login')
def editTrainer(request):
    if request.user.is_superuser and request.method == 'POST':
        id = request.POST['id']
        obj = Trainer.objects.get(id=id)
        return render(request, 'admin/editTrainer.html', {'data': obj})


@login_required(login_url='/admin/login')
def editTrainerDetails(request):
    if request.user.is_superuser and request.method == 'POST':
        id = request.POST['id']
        isActive = request.POST['isActive']
        obj = Trainer.objects.get(id=id)
        obj.isActive = isActive
        obj.save()
        messages.success(request, 'Done !!')
        return redirect('trainerManage')


@login_required(login_url='/admin/login')
def deleteTrainer(request):
    if request.user.is_superuser and request.method == 'POST':
        id = request.POST['id']
        obj = Trainer.objects.get(id=id)
        obj.delete()
        messages.success(request, 'Deleted Successfully')
        return redirect('trainerManage')


@login_required(login_url='/admin/login')
def editUser(request):
    if request.user.is_superuser and request.method == 'POST':
        id = request.POST['id']
        obj = Customer.objects.get(id=id)
        return render(request, 'admin/editUser.html', {'data': obj})


@login_required(login_url='/admin/login')
def editUserDetails(request):
    if request.user.is_superuser and request.method == 'POST':
        id = request.POST['id']
        isActive = request.POST['isActive']
        obj = Customer.objects.get(id=id)
        obj.isActive = isActive
        obj.save()
        messages.success(request, 'Done !!')
        return redirect('customerManage')


@login_required(login_url='/admin/login')
def deleteUser(request):
    if request.user.is_superuser and request.method == 'POST':
        id = request.POST['id']
        obj = Customer.objects.get(id=id)
        obj1 = obj.user
        obj1.delete()
        obj.delete()
        messages.success(request, 'Deleted Successfully')
        return redirect('customerManage')


@login_required(login_url='/admin/login')
def feedbacksList(request):
    if request.user.is_superuser:
        obj = feedback.objects.all()
        return render(request, 'admin/feedbacksList.html', {'feedbacksList': obj})


def userLogin(request):
    if request.method == 'POST':
        username = request.POST['username']
        passwd = request.POST['password']
        user = auth.authenticate(username=username, password=passwd)
        if user is not None:
            auth.login(request, user)
            return redirect('userProfile')
        else:
            messages.error(request, 'Username or Password is wrong !!!')
            return redirect('userLogin')
    else:
        return render(request, 'customer/login.html')


def userRegister(request):
    if request.method == 'POST':
        Name = request.POST['name']
        email = request.POST['email']
        mbl = request.POST['mbl']
        address = request.POST['address']
        password = request.POST['password']
        # pic = request.POST['pic']
        id = random.randint(100, 250000000)
        if User.objects.filter(username=mbl).exists():
            messages.error(request, 'Mobile Number is already exists.')
            return redirect('userRegister')
        elif len(password) < 8:
            messages.error(request, 'Password length should be 8 or more.')
            return redirect('userRegister')
        else:
            user = User.objects.create_user(first_name=Name, username=mbl, email=email, password=password)
            user.save()
            cust = Customer(id=id, user=user, isActive='Yes', address=address, profileImg=None)
            cust.save()
            return redirect('userLogin')
    else:

        return render(request, 'customer/register.html')




@login_required(login_url='customer/login')
def userProfile(request):
    if request.user.is_authenticated:
        name = request.user
        obj = Customer.objects.get(user=name)
        return render(request, 'customer/profile.html', {'data': obj})


@login_required(login_url='customer/login')
def editUserProfile(request):
    if request.user.is_authenticated and not request.user.is_superuser:
        object = request.user
        obj = Customer.objects.get(user=object)
        return render(request, 'customer/editProfile.html', {'data': obj})


@login_required(login_url='customer/login')
def saveUserDetails(request):
    if request.user.is_authenticated and not request.user.is_superuser:
        id = request.POST['id']
        name = request.POST['name']
        address = request.POST['id']
        img = request.POST['id']
        passwd = request.POST['password']
        obj = Customer.objects.get(id=id)
        userObj = obj.user
        userObj.set_password(passwd)
        userObj.first_name = name
        userObj.save()
        auth.login(request, userObj)
        obj.address = address
        obj.profileImg = img
        obj.save()
        return redirect('userProfile')


@login_required(login_url='customer/login')
def userLogout(request):
    if request.user.is_authenticated and not request.user.is_superuser:
        auth.logout(request)
        return redirect('userLogin')
    else:
        messages.error(request, 'Unable to logout')
        return redirect('userProfile')


userNumber = 0
userEmail = ''


def UserForgotPassword(request):
    global userNumber, userEmail
    if request.method == 'POST':
        email = request.POST['email']
        userNumber = random.randint(100000, 900000)
        try:
            s = smtplib.SMTP('smtp.gmail.com', 587)
            s.starttls()
            s.login("bharathsr2001@gmail.com", "Bharath@B26")
            message = "Forgot Password\n OTP : {}".format(userNumber)
            s.sendmail("bharathsr2001@gmail.com", email, message)
            s.quit()
            userEmail = email
            # messages.success(request, 'Successfully Sent')
            return redirect('userOTP')
        except:
            messages.success(request, 'Unable to Sent')
            return redirect('userLogin')
    else:
        return render(request, 'customer/forgotPassword.html')


def userOTP(request):
    global userNumber
    if request.method == 'POST':
        print('lop')
        n1 = request.POST['n1']
        n2 = request.POST['n2']
        n3 = request.POST['n3']
        n4 = request.POST['n4']
        n5 = request.POST['n5']
        n6 = request.POST['n6']
        if n1.isdigit() and n2.isdigit() and n3.isdigit() and n4.isdigit() and n5.isdigit() and n6.isdigit():
            n = int(n1 + n2 + n3 + n4 + n5 + n6)
            if n == userNumber:
                return redirect('changeUserPassword')
            else:
                messages.error(request, 'OTP is wrong')
                return redirect('userOTP')
        else:
            messages.error(request, 'It should be digit')
            return redirect('userOTP')
    else:
        return render(request, 'customer/otp.html')


def changeUserPassword(request):
    global userNumber, userEmail
    if request.method == 'POST':
        p1 = request.POST['p1']
        p2 = request.POST['password']
        if p1 == p2:
            try:
                obj = User.objects.get(email=userEmail)
            except:
                obj = None
            if obj is not None:
                obj.set_password(p1)
                obj.save()
                auth.login(request, obj)
                messages.success(request, 'Password changed successfully..')
                return redirect('userLogin')
            else:
                messages.error(request, 'Unable to change the password..')
                return redirect('userLogin')
    else:
        return render(request, 'customer/changePassword.html')


@login_required(login_url='/customer/login')
def paymentForm(request):
    if request.user.is_authenticated:
        return render(request, 'customer/paymentForm.html')


@login_required(login_url='/customer/login')
def customerPackageList(request):
    if request.user.is_authenticated:
        obj = Package.objects.all()
        return render(request, 'customer/packageList.html', {'packageList': obj})


@login_required(login_url='/customer/login')
def yourPackages(request):
    if request.user.is_authenticated and not request.user.is_superuser:
        obj = request.user
        obj1 = Customer.objects.get(user=obj)
        obj2 = Booking.objects.filter(customerID=obj1, IsAccepted='Yes')
        return render(request, 'customer/yourPackages.html', {'list': obj2})


@login_required(login_url='/customer/login')
def viewInfo(request):
    if request.user.is_authenticated:
        obj=notifications.objects.all()
        return render(request, 'customer/viewInfo.html',{'news':obj})


@login_required(login_url='/customer/login')
def customerBooking(request):
    if request.user.is_authenticated and request.method == 'POST':
        id = request.POST['id']
        obj = Package.objects.get(id=id)
        obj1 = request.user
        obj2 = Customer.objects.get(user=obj1)
        date = datetime.date.today()
        isAccepted = 'Yes'
        print(id)
        if Booking.objects.filter(customerID=obj2, packageID=obj).exists():
            messages.error(request, 'Already Booked.')
            return redirect("customerPackageList")
        else:
            book = Booking(customerID=obj2, packageID=obj, date=date, IsAccepted=isAccepted)
            book.save()
            messages.success(request, 'Booked Successfully.')
            return redirect('yourPackages')
    else:
        return redirect('userLogin')


@login_required(login_url='/customer/login')
def checkCustomerAttendance(request):
    if request.user.is_authenticated and request.method == 'POST':
        month = request.POST['month']
        obj = request.user
        customer = Customer.objects.get(user=obj)
        print(month)
        ob = Attendance_Customer.objects.filter(customerID=customer, monthValue=month)
        return render(request, 'customer/viewAttendance.html', {'attendanceList': ob})


@login_required(login_url='/customer/login')
def viewAttendance(request):
    if request.user.is_authenticated:
        return render(request, 'customer/viewAttendance.html')


@login_required(login_url='/customer/login')
def customerFeedback(request):
    if request.user.is_authenticated and request.method == 'POST':
        rating = request.POST['feedback']
        suggestions = request.POST['msg']
        user = request.user
        obj = Customer.objects.get(user=user)
        feedbackObj = feedback(customerID=obj, rating=rating, suggestions=suggestions)
        feedbackObj.save()
        return redirect('userProfile')


trainerUsername = ''


def trainerLogin(request):
    global trainerUsername
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']
        if Trainer.objects.filter(mbl=username, password=password).exists():
            trainerUsername = username
            return redirect('trainerProfile')
        else:
            messages.error(request, 'Username or Password is wrong!!')
            return redirect('trainerLogin')
    else:
        return render(request, 'trainer/login.html')


def trainerLogout(request):
    global trainerUsername
    trainerUsername = ''
    return redirect('trainerLogin')


def addInfo(request):
    global trainerUsername
    if trainerUsername is None:
        return redirect('trainerLogin')
    else:
        if request.method == 'POST':
            form=UpdateInformation(request.POST,request.FILES)
            if form.is_valid():
                form.save()
                print('Saved')
            return redirect('trainerProfile')
        else:
            form=UpdateInformation()
            return render(request, 'trainer/addInfo.html',{'form':form})


def displayAttendance(request):
    global trainerUsername
    if trainerUsername is None:
        return redirect('trainerLogin')
    else:
        return render(request, 'trainer/displayAttendance.html')


def checkTrainerAttendance(request):
    if request.method == 'POST':
        month = request.POST['month']
        obj = Trainer.objects.get(mbl=trainerUsername)
        print(month)
        ob = Attendance_Trainer.objects.filter(trainer_ID=obj, monthValue=month)
        print(ob)
        return render(request, 'trainer/displayAttendance.html', {'attendanceList': ob})


def trainerProfile(request):
    global trainerUsername
    if trainerUsername is None:
        return redirect('trainerLogin')
    else:
        obj = Trainer.objects.get(mbl=trainerUsername)
        return render(request, 'trainer/profile.html', {'data': obj})


def viewCustomer(request):
    global trainerUsername
    if trainerUsername is None:
        return redirect('trainerLogin')
    else:
        obj = Customer.objects.all()
        return render(request, 'trainer/viewCustomer.html', {'customersList': obj})


def trainerEditProfile(request):
    global trainerUsername
    if trainerUsername is None:
        return redirect('trainerLogin')
    else:
        if request.method == 'POST':
            id = request.POST['id']
            name = request.POST['name']
            address = request.POST['address']
            password = request.POST['password']
            trainerObject = Trainer.objects.get(id=id)
            trainerObject.name = name
            trainerObject.address = address
            trainerObject.password = password
            trainerObject.save()
            messages.success(request, 'Done.')
            return redirect('trainerProfile')
        else:
            obj = Trainer.objects.get(mbl=trainerUsername)
            return render(request, 'trainer/editProfile.html', {'data': obj})


trainerEmail = ''
trainerNumber = 0


def TrainerForgotPassword(request):
    global trainerNumber, trainerEmail
    if request.method == 'POST':
        email = request.POST['email']
        trainerNumber = random.randint(100000, 900000)
        try:
            s = smtplib.SMTP('smtp.gmail.com', 587)
            s.starttls()
            s.login("bharathsr2001@gmail.com", "Bharath@B26")
            message = "Forgot Password\n OTP : {}".format(trainerNumber)
            s.sendmail("bharathsr2001@gmail.com", email, message)
            s.quit()
            trainerEmail = email
            # messages.success(request, 'Successfully Sent')
            return redirect('trainerOTP')
        except:
            messages.success(request, 'Unable to Sent')
            return redirect('trainerLogin')
    else:
        return render(request, 'trainer/forgotPassword.html')


def trainerOTP(request):
    global trainerNumber
    if request.method == 'POST':
        n1 = request.POST['n1']
        n2 = request.POST['n2']
        n3 = request.POST['n3']
        n4 = request.POST['n4']
        n5 = request.POST['n5']
        n6 = request.POST['n6']
        if n1.isdigit() and n2.isdigit() and n3.isdigit() and n4.isdigit() and n5.isdigit() and n6.isdigit():
            n = int(n1 + n2 + n3 + n4 + n5 + n6)
            if n == trainerNumber:
                return redirect('changeTrainerPassword')
            else:
                messages.error(request, 'OTP is wrong')
                return redirect('trainerOTP')
        else:
            messages.error(request, 'It should be digit')
            return redirect('trainerOTP')
    else:
        return render(request, 'trainer/otp.html')

def changeTrainerPassword(request):
    global trainerEmail
    if request.method=='POST':
        p1=request.POST['p1']
        p2=request.POST['password']
        if p1==p2:
            try:
                obj=Trainer.objects.get(email=trainerEmail)
            except:
                obj=None
            if obj is not None:
                obj.password=p1
                obj.save()
                messages.success(request,'Password is changed successfully..')
                return redirect('trainerLogin')
            else:
                messages.error(request,'Trainer not found..')
                return redirect('trainerLogin')
        else:
            messages.error(request,'Passwords are not matching...')
            return redirect('changeTrainerPassword')
    else:
        return render(request,'trainer/changePassword.html')