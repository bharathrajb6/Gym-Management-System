from django.contrib import admin
from gym.models import Customer,Trainer,Package,Booking,Payment,Attendance_Customer,Attendance_Trainer,Service,feedback,Admin,notifications

# Register your models here.

admin.site.register(Customer)
admin.site.register(Trainer)
admin.site.register(Package)
admin.site.register(Booking)
admin.site.register(Payment)
admin.site.register(Attendance_Customer)
admin.site.register(Attendance_Trainer)
admin.site.register(Service)
admin.site.register(Admin)
admin.site.register(notifications)