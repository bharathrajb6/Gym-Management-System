from django import forms
from .models import Package, Service,notifications
import random


class PackageForm(forms.ModelForm):
    class Meta:
        model = Package
        fields = '__all__'


class ServiceForm(forms.ModelForm):
    class Meta:
        model = Service
        fields = '__all__'


class UpdateInformation(forms.ModelForm):
    class Meta:
        model=notifications
        fields='__all__'


