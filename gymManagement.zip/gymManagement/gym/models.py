import datetime
from django.db import models as mo
from django.contrib.auth.models import auth, User
from django.utils.timezone import now


class Customer(mo.Model):
    user = mo.OneToOneField(to=User, on_delete=mo.CASCADE)  # using built-in auth model
    isActive = mo.CharField(max_length=3, blank=None)
    address = mo.TextField(max_length=20, default=None)
    profileImg = mo.ImageField(upload_to='Profile')

    def __str__(self):
        return self.user.email


class Trainer(mo.Model):
    id = mo.IntegerField(default=None, primary_key=True)
    name = mo.CharField(max_length=20, default=None)
    isActive = mo.CharField(max_length=3, default=None)
    email = mo.EmailField(default=None, max_length=30)
    mbl = mo.BigIntegerField(default=None)
    password = mo.CharField(max_length=12, default=None)
    address = mo.CharField(default=None, max_length=40)

    def __str__(self):
        return self.name


class Package(mo.Model):
    id = mo.AutoField(primary_key=True)
    package_Name = mo.CharField(default=None, max_length=20)
    package_Desc = mo.TextField(max_length=50, default=None)
    package_Price = mo.IntegerField(default=None)
    package_Image = mo.ImageField(upload_to='PackagePhotos')

    def __str__(self):
        return self.package_Name


class Service(mo.Model):
    serviceName = mo.CharField(default=None, max_length=20)
    serviceDesc = mo.TextField(max_length=40, default=None)
    servicePrice = mo.IntegerField(default=None)
    serviceImage = mo.ImageField(upload_to='ServicePhotos')

    def __str__(self):
        return self.serviceName


class Attendance_Customer(mo.Model):
    customerID = mo.ForeignKey(to=Customer, on_delete=mo.CASCADE)
    date = mo.DateField(default=datetime.date.today())
    monthValue = mo.TextField(max_length=10, blank=None)
    isPresent = mo.CharField(max_length=3, blank=None)

    def __str__(self):
        return self.customerID.user.email


class Attendance_Trainer(mo.Model):
    trainer_ID = mo.ForeignKey(to=Trainer, on_delete=mo.CASCADE)
    date = mo.DateField(default=datetime.date.today())
    monthValue = mo.TextField(max_length=10,default='')
    IsPresent = mo.CharField(max_length=3, blank=None)

    def __str__(self):
        return self.trainer_ID.name


class Booking(mo.Model):
    customerID = mo.ForeignKey(to=Customer, on_delete=mo.CASCADE)
    packageID = mo.ForeignKey(to=Package, on_delete=mo.CASCADE)
    date = mo.DateField(default=datetime.date.today())
    IsAccepted = mo.CharField(max_length=3, blank=None)

    def __str__(self):
        return self.customerID.user.email


class Admin(mo.Model):
    username = mo.CharField(max_length=20, default=None, primary_key=True)
    password = mo.CharField(max_length=20)

    def __str__(self):
        return self.username


class Payment(mo.Model):
    customerID = mo.ForeignKey(to=Customer, on_delete=mo.CASCADE)
    packageID = mo.ForeignKey(to=Package, on_delete=mo.CASCADE)
    month = mo.DateField(default=datetime.date.today())
    cost = mo.IntegerField()
    isPaid = mo.CharField(max_length=3, blank=None)

    def __str__(self):
        return self.id


class notifications(mo.Model):
    title = mo.CharField(max_length=30, blank=None)
    description = mo.TextField(max_length=150, default='')
    pic = mo.ImageField(upload_to='Notifications', default='')

    def __str__(self):
        return self.title


class feedback(mo.Model):
    customerID = mo.ForeignKey(to=Customer, on_delete=mo.CASCADE)
    rating = mo.CharField(max_length=10, blank=None)
    suggestions = mo.TextField(max_length=100, blank=None)


    def __str__(self):
        return self.customerID.id
